const girlsNames = [
    {fullFirstName: "Anastasia", shortFirstName: "Nastia", isPopular: true },
    {fullFirstName: "Kateryna", shortFirstName: "Katia", isPopular: true },
    {fullFirstName: "Olga", shortFirstName: "Olya", isPopular: true },
    {fullFirstName: "Tatiana", shortFirstName: "Nastia", isPopular: true },
    {fullFirstName: "Stefania", shortFirstName: "Stefa", isPopular: false }
];
const boysNames = [
    {fullFirstName: "Andrey", shortFirstName: "Andrey", isPopular: false },
    {fullFirstName: "Ivan", shortFirstName: "Vania", isPopular: true },
    {fullFirstName: "Titomir", shortFirstName: "Tito", isPopular: false },
    {fullFirstName: "Oleg", shortFirstName: "Oleg", isPopular: false }
]

for (i = 0; i < boysNames.length;  i++) {
    console.log(boysNames[i].fullFirstName);
}

const secondName = "Zhei";

if(secondName != "Zhenia") {
    console.log("I am not Zhenia :(")
} else {
console.log("I am Zhenia :)")
}
let applesCount = 2;

while (applesCount < 5) {
    console.log("I have less than 5 apples, which is" + " " + applesCount);
    applesCount++;
}
console.log("End!");

for (applesCount = 0; applesCount < 10; applesCount++) {
    console.log("I have" + " " + applesCount + " " + "Apples!");
    if (applesCount === 1) {
        console.log("I have" + " " + applesCount + " " + "Apple!");
    }
}
console.log("End!");

let mermaidsNames = ["Jeanne", "Lia", "Chloe"];

for (i = 0; i < mermaidsNames.length; i++) {
    console.log("I am a mermaid and my name is " + mermaidsNames[i] + ".");
};

let uniqueName = "Patricia";

for(i = 0; i < uniqueName.length; i++) {
    console.log("This letter is " + uniqueName[i] + ".");
}


// --------------------------------  Home Work  ----------------Chapter 4: Objects-------------------\\


//1

const scores = {
     "Vanya": {
        firstName: "Vanya",
        scoreNumber: 0
    } ,
    "Zhenia": {
        firstName: "Zhenia",
        scoreNumber: 0
    }
};
let vanyaScore = scores.Vanya;
let zheniaScore = scores.Zhenia;

vanyaScore.scoreNumber = 15;
zheniaScore.scoreNumber = 3;

console.log(vanyaScore.scoreNumber);
console.log(zheniaScore.scoreNumber);


//2 

var myCrazyObject = {
    "name": "Нелепыйобъект",
    "some array": [7, 9, { purpose: "путаница", number: 123 }, 3.3],
    "random animal": "Банановаяакула"
};
let randomNumber = myCrazyObject["some array"];
console.log(randomNumber[2].number);


// --------------------------------------Chapter 6: Conditions and Loops----------------------------------------\\


//1

let animals = ["Кот", "Рыба", "Лемур", "Комодскийваран"];

for (i = 0; i < animals.length; i++) {
    console.log(animals[i] + " " + "- прекрасное животное");
};


//2 

let  alphabet = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";
let  randomString = " ";

while (randomString.length < 6) {
    randomString += alphabet[Math.floor(Math.random() * alphabet.length)];
    console.log(randomString);
};


//3

let  input = "javascript is awesome";
let  output = "";
 
for (i = 0; i < input.length; i++) {
    if (input[i] === "a") {
        output += "4";
    } else if (input[i] === "e") {
        output += "3";
    }  else if (input[i] === "i") {
        output += "1";
    }  else if (input[i] === "o") {
        output += "0";
    } else  {
        output += input[i];
    } 
}
console.log(output);


//-----------viselitsa----------------\\

let userName = prompt("What is your name?");
alert("Hi, " + userName + " !");
if (!userName) {
    alert ("Hey, no name - no fun game!")
}
const wordsList = [
    "kitten",
    "rose",
    "vanilla",
    "bear",
    "doritos"
];
let guessWord = wordsList[Math.floor(Math.random() * wordsList.length)];

answersList = [];
for (i = 0; i < guessWord.length; i++) {
    answersList[i] = "_";
}
let answerRemainingLetters = guessWord.length;
attemptValue = 3;

while (answerRemainingLetters > 0 && attemptValue > 0) {
    alert(answersList.join(" "));
    let guessWindow = prompt("Guess one letter or press Cancel to exit the game.");
      if (!guessWindow) {
        break;
    } else if (guessWindow.length !== 1) {
        alert ("Please, enter the  character.");
    } else {
        attemptValue--;
        guess = guessWindow.toLowerCase();
        for (letter = 0; letter < guessWord.length; letter ++) {
            if (guessWord[letter] === guess && answersList[letter] === "_") {
             answersList[letter] = guess;
             answerRemainingLetters--;
             }
        }
    }
}
   if (attemptValue > 0) {
    alert (answersList.join(" "));
    alert("Great job! The word is " + guessWord);
   }   else {
    alert("Pam pam pam. The word is " + guessWord);
   }

//---------------Chapter exercises---------------\\

wordsList.push("AC\DC", "fuchsia", "marriage");
//see others above in the code


