const createGrid = ({id, productUrl, title, description}) => {
    return  ` 
        <div class="product-container product${id}">
            <img src="${productUrl}" alt="" class="product-img">
            <h2 class="product-title">${title}</h2>
            <h3 class="product-description">${description.slice(0, 50)}</h3>
        </div>
    `
}

const createDiv = (root, products) => {
    const container = document.createElement('div');
    container.className = 'grid-container';

    let productInfo = '';
    products.forEach(item => {
        let info = createGrid(item);
        productInfo += info;
    });
    
    container.insertAdjacentHTML('beforeend', productInfo)
    root.prepend(container)
};

const insertData = (root = document.querySelector('body')) => {
fetch ('http://localhost:3000/toys')
.then ((response) => {
    return response.json();
})
.then ((data) => {
    createDiv(root, data);
    addExpandMode(root, data)
console.log(data)
})
.catch ((err) => {
    console.log(err)
})
}
insertData();

//-----------------------expandMode-----------------------\\

const createExpandMode = ({productUrl, title, description}) => {
    return  ` 
    <div class="item_expanded">
        <img src="${productUrl}" alt="" class="item_expanded-img">
        <h2 class="item_expanded-title">${title}</h2>
        <h3 cl  ass="item_expanded-description">${description}</h3>
    </div>
    `
}
const addExpandMode = (root =  document.querySelector('.grid-container'), info) => {
    let expandItem = '';
    info.forEach(item => {
        expandItem +=  createExpandMode(item);
    })
   root.insertAdjacentHTML('beforeend', expandItem)
}

window.onload = function enableExpandMode () {
    const  products = document.querySelectorAll('.product-container');
    console.log(products)
    products.forEach.call(products,(item, index) => {
        item.addEventListener('mouseenter', () => {
            const expandedItem = document.querySelectorAll('.item_expanded');
            expandedItem.forEach((expandee, i) => {
                if (i === index) {
                    expandee.classList.add('expanded');
                    console.log( expandee + ' Opened! ' + item)
                }
            })
        })
        item.addEventListener('mouseleave', () => {
            document.querySelectorAll('.item_expanded').forEach((expandee, i) => {
                if (i === index ) {
                    expandee.classList.remove('expanded');
                    console.log('Closed!')
                }
           })
        })
    })

   

}

