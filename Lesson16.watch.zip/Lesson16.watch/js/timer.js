const normalizeTime = time => {
    return time < 10 ? `0${time}` : time;
}

export class Timer {
    constructor (root) {
        this.root = root;
        this.render();
    }
    render () {
        this.timer = document.createElement('div');
        this.timer.className = 'timer';

        this.buttons = document.createElement('div');
        this.buttons.className = 'timer__action-bar'

        this.startBtn = document.createElement('button');
        this.startBtn.className = 'timer-start-btn';
        this.startBtn.textContent = 'START'
        
        this.stopBtn = document.createElement('button');
        this.stopBtn.className = 'timer-stop-btn';
        this.stopBtn.textContent = 'STOP';

        this.form = document.createElement("form");
        this.form.className = 'timer__input'
        this.hours = document.createElement('input');
        this.minutes = document.createElement('input');
        this.seconds = document.createElement('input');

        this.form.append(this.hours, this.minutes, this.seconds);
        this.buttons.append(this.startBtn, this.stopBtn)

        this.timer.append(this.form, this.buttons)
        this.root.append(this.timer);

        this.hours.value = '00';
        this.minutes.value = '00';
        this.seconds.value = '00';

        this.startBtn.addEventListener('click', () => {
            let hour =   this.hours.value;
            let minute = this.minutes.value;
            let second = this.seconds.value;
            this.startBtn.disabled = true;
            this.stopBtn.disabled = false;
            this.displayTime(hour, minute, second);
        })        
    }
    displayTime (hour, minute, second) {
        let date = new Date(Date.now()).getTime();
        let miliseconds = (hour * 360) + (minute * 60000 ) + (second * 1000);
        let time = date + miliseconds;
        console.log(miliseconds)

        let interval = setInterval(() => {
            let now = new Date().getTime();
            console.log(now)
            let total = time - now;

           let hours = Math.floor((total % (1000 * 60 * 60 * 24)) /  (1000 * 60 * 60));
           let minutes = Math.floor((total % (1000 * 60 * 60)) /  (1000 * 60));
           let seconds = Math.floor((total % (1000 * 60)) /  1000);

           if (hours == 0 && minutes == 0 && seconds == 0) {
            clearInterval(interval);
            this.hours.value = '00';
            this.minutes.value = '00';
            this.seconds.value = '00';
            this.stopBtn.disabled = true;
            this.startBtn.disabled = false;

           }

           console.log(total)

        this.hours.value = hours.toString();
        this.minutes.value = minutes.toString();
        this.seconds.value = seconds.toString();
        }, 1000)  

        this.stopBtn.addEventListener('click', () => {
            clearInterval(interval);
            this.hours.value = '00';
            this.minutes.value = '00';
            this.seconds.value = '00';
            this.stopBtn.disabled = true;
            this.startBtn.disabled = false;
        })
    }
    setHour () {
        let date = new Date('December 31 2020 00:00:00');
        let h = normalizeTime(date.getHours());
        return h
    }
    setMinute () {
        let date = new Date('December 31 2020 00:00:00');
        let m = normalizeTime(date.getMinutes(0));
        return m
    }
    setSecond () {
        let date = new Date('December 31 2020 00:00:00');
        let s = normalizeTime(date.getSeconds(0));
        return s
    }
}