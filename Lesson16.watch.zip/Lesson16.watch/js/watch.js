const normalizeTime = time => {
        return time < 10 ? `0${time}` : time;
}
const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export class Clock {
    constructor (root) {
        this.root = root;
        this.render();
        this.activeMode = 2;
    }

    render() {
        this.container = document.createElement('div');
        this.container.className = 'widget__container';

        this.content = document.createElement('div');
        this.content.className = 'widget__content';

        this.clock = document.createElement('h1');
        this.clock.className = 'widget__clock';

        this.bar = document.createElement('div');
        this.bar.className = 'widget__mode-switch-bar';

        this.shortModeBtn = document.createElement('button');
        this.shortModeBtn.className = 'clock__short-mode-btn';
        this.shortModeBtn.textContent = 'SHORT MODE';

        this.longModeBtn = document.createElement('button');
        this.longModeBtn.className = 'clock__long-mode-btn';
        this.longModeBtn.textContent = 'LONG MODE';
        
        this.bar.append(this.shortModeBtn, this.longModeBtn);
        this.content.append(this.clock, this.bar);
        this.container.append(this.content);
        this.root.append(this.container);

        this.setClock()
    }

    setClock () {
        setInterval(() => this.renderTime());
        this.longModeBtn.addEventListener('click', () => {
           this.increaseMode();
        });
        this.shortModeBtn.addEventListener('click', () => {
            this.decreaseMode();
         })
                
    }
    renderTime () {
        switch (this.activeMode) {
            case 1 :
            this.clock.textContent = this.getLong();
            break;
            case 0:
            this.clock.textContent = this.getShort();
            break;
            case 2:
            this.clock.textContent = this.getDate()
        }
    }
    getLong () {
        let date = new Date();
        let h = normalizeTime(date.getHours());
        let m = normalizeTime(date.getMinutes());
        let s = normalizeTime(date.getSeconds());

        return `${h} : ${m} : ${s}`;
    }
    getShort () {
        let date = new Date();
        let h = normalizeTime(date.getHours());
        let m = normalizeTime(date.getMinutes());

        return`${h} : ${m}`;
    }
    getDate () {
        let date = new Date();
        let d = days[date.getDay()];
        let dt = date.getDate();
        let y = date.getFullYear();
        this.activeMode = 2;

        return `${dt} / ${d} / ${y}`
    }
    increaseMode () {
        this.activeMode = 1;
        console.log(this.activeMode)
    }
    decreaseMode () {
        this.activeMode = 0;
        console.log(this.activeMode)
    }
}
