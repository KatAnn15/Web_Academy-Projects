import {    Clock    } from './watch.js';
import {    Timer   } from './timer.js'

new Timer (document.querySelector('main'))
new Clock(document.querySelector('main'));
